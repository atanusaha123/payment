# Payment Gateway

-----------------------------------------------------------------------------------------------------

<img src="/screenshots/Payment-Gateway-Home-Page.JPG" />

-----------------------------------------------------------------------------------------------------

<img src="/screenshots/Payment-Gateway-Payment-Page.JPG" />

-----------------------------------------------------------------------------------------------------

## Development

git clone https://github.com/PranamBhat/Payment-Gateway.git

cd Payment-Gateway

Go to Visual Studio Code

Right click on demo.html > Open In Other Browsers > Google Chrome

The app will automatically reload on Google Chrome (Press "F5" if you change any of the source files).


### From Developer

Made with :heart: by Pranam Bhat. Follow me on https://www.linkedin.com/in/pranam-bhat-11670689/

For any queries : pranam707@gmail.com
